import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PersonaService {

  private baseUrl = '/persona';

  constructor(private http: HttpClient) { }

  getPersona(dni: string): Observable<Object> {
    return this.http.get(`${this.baseUrl}/${dni}`);
  }

  createPersona(persona: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}`, persona);
  }

  updatePersona(dni: string, value: any): Observable<Object> {
    return this.http.put(`${this.baseUrl}/${dni}`, value);
  }

  deletePersona(dni: string): Observable<any> {
    return this.http.delete(`${this.baseUrl}/${dni}`, { responseType: 'text' });
  }

  getPersonaList(): Observable<any> {
    return this.http.get(`${this.baseUrl}`);
  }
}