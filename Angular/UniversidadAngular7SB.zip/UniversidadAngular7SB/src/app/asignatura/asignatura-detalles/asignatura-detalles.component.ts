import { Asignatura } from '../../asignatura';
import { Component, OnInit, Input } from '@angular/core';
import { AsignaturaService } from '../../asignatura.service';
import { AsignaturaListaComponent } from '../asignatura-lista/asignatura-lista.component';

@Component({
  selector: 'app-asignatura-detalles',
  templateUrl: './asignatura-detalles.component.html',
  styleUrls: ['./asignatura-detalles.component.css']
})
export class AsignaturaDetallesComponent implements OnInit {

  @Input() asignatura: Asignatura;

  constructor(private asignaturaService: AsignaturaService, private listComponent: AsignaturaListaComponent) { }

  ngOnInit() {
  }
}
