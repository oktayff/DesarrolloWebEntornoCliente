import { Observable } from "rxjs";
import { AsignaturaService } from "../../asignatura.service";
import { Asignatura } from "../../asignatura";
import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-asignatura-lista",
  templateUrl: "./asignatura-lista.component.html",
  styleUrls: ["./asignatura-lista.component.css"]
})
export class AsignaturaListaComponent implements OnInit {
  asignaturas: Observable<Asignatura[]>;

  constructor(private asignaturaService: AsignaturaService) {}

  ngOnInit() {
    this.reloadData();
  }

  reloadData() {
    this.asignaturas = this.asignaturaService.getAsignaturaList();
  }

  deleteAsignatura(idprofesor: string) {
    this.asignaturaService.deleteAsignatura(idprofesor)
      .subscribe(
        data => {
          console.log(data);
          this.reloadData();
        },
        error => console.log(error));
  }
}
