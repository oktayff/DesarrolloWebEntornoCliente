import { AsignaturaService } from '../../asignatura.service';
import { Asignatura } from '../../asignatura';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-crear-asignatura',
  templateUrl: './crear-asignatura.component.html',
  styleUrls: ['./crear-asignatura.component.css']
})
export class CrearAsignaturaComponent implements OnInit {

  asignatura: Asignatura = new Asignatura();
  submitted = false;

  constructor(private asignaturaService: AsignaturaService) { }

  ngOnInit() {
  }

  newAlumno(): void {
    this.submitted = false;
    this.asignatura = new Asignatura();
  }

  save() {
    this.asignaturaService.createAsignatura(this.asignatura)
      .subscribe(data => console.log(data), error => console.log(error));
    this.asignatura = new Asignatura();
  }

  onSubmit() {
    this.submitted = true;
    this.save();
  }
}
