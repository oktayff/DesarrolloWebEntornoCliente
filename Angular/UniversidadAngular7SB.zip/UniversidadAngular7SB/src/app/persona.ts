export class Persona {
    dni: string;
    nombre: string;
    apellido: string;
    ciudad: string;
    direccioncalle: string;
    direccionnum: number;
    telefono: string;
    fecha_nacimiento: Date;
    varon: number;
}