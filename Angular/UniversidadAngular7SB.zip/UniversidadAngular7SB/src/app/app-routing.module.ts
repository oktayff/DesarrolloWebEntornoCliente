//Titulacion
import { TitulacionDetallesComponent } from './titulacion/titulacion-detalles/titulacion-detalles.component';
//Persona
import { PersonaDetallesComponent } from './persona/persona-detalles/persona-detalles.component';
//Alumno
import { AlumnoDetallesComponent } from './alumno/alumno-detalles/alumno-detalles.component';
//Profesor
import { ProfesorDetallesComponent } from './profesor/profesor-detalles/profesor-detalles.component';
//Asignatura
import { AsignaturaDetallesComponent } from './asignatura/asignatura-detalles/asignatura-detalles.component';

//Titulacion
import { CrearTitulacionComponent } from './titulacion/crear-titulacion/crear-titulacion.component';
//Persona
import { CrearPersonaComponent } from './persona/crear-persona/crear-persona.component';
//Alumno
import { CrearAlumnoComponent } from './alumno/crear-alumno/crear-alumno.component';
//Profesor
import { CrearProfesorComponent } from './profesor/crear-profesor/crear-profesor.component';
//Asignatura
import { CrearAsignaturaComponent } from './asignatura/crear-asignatura/crear-asignatura.component';

import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

//Titulacion
import { TitulacionListaComponent } from './titulacion/titulacion-lista/titulacion-lista.component';
//Persona
import { PersonaListaComponent } from './persona/persona-lista/persona-lista.component';
//Alumno
import { AlumnoListaComponent } from './alumno/alumno-lista/alumno-lista.component';
//Profesor
import { ProfesorListaComponent } from './profesor/profesor-lista/profesor-lista.component';
//Asignatura
import { AsignaturaListaComponent } from './asignatura/asignatura-lista/asignatura-lista.component';

const routes: Routes = [

  //Titulacion
  { path: '', redirectTo: 'titulacion', pathMatch: 'full' },
  { path: 'ListaTitulacion', component: TitulacionListaComponent },
  { path: 'anadirtitulacion', component: CrearTitulacionComponent },

  //Persona
  { path: '', redirectTo: 'persona', pathMatch: 'full' },
  { path: 'ListaPersona', component: PersonaListaComponent },
  { path: 'anadirpersona', component: CrearPersonaComponent },

  //Alumno
  { path: '', redirectTo: 'alumno', pathMatch: 'full' },
  { path: 'ListaAlumno', component: AlumnoListaComponent },
  { path: 'anadiralumno', component: CrearAlumnoComponent },

  //Profesor
  { path: '', redirectTo: 'profesor', pathMatch: 'full' },
  { path: 'ListaProfesor', component: ProfesorListaComponent },
  { path: 'anadirprofesor', component: CrearProfesorComponent },

  //Asignatura
  { path: '', redirectTo: 'asignatura', pathMatch: 'full' },
  { path: 'ListaAsignatura', component: AsignaturaListaComponent },
  { path: 'anadirasignatura', component: CrearAsignaturaComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
