import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProfesorService {

  private baseUrl = '/profesor';

  constructor(private http: HttpClient) { }

  getProfesor(dni: string): Observable<Object> {
    return this.http.get(`${this.baseUrl}/${dni}`);
  }

  createProfesor(profesor: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}`, profesor);
  }

  updateProfesor(dni: string, value: any): Observable<Object> {
    return this.http.put(`${this.baseUrl}/${dni}`, value);
  }

  deleteProfesor(dni: string): Observable<any> {
    return this.http.delete(`${this.baseUrl}/${dni}`, { responseType: 'text' });
  }

  getProfesorList(): Observable<any> {
    return this.http.get(`${this.baseUrl}`);
  }
}
