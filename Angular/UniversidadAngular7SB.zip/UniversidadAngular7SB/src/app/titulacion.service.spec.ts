import { TestBed } from '@angular/core/testing';

import { TitulacionService } from './titulacion.service';

describe('TitulacionService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: TitulacionService = TestBed.get(TitulacionService);
    expect(service).toBeTruthy();
  });
});
