import { Observable } from "rxjs";
import { ProfesorService } from "../../profesor.service";
import { Profesor } from "../../profesor";
import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-profesor-lista",
  templateUrl: "./profesor-lista.component.html",
  styleUrls: ["./profesor-lista.component.css"]
})
export class ProfesorListaComponent implements OnInit {
  profesores: Observable<Profesor[]>;

  constructor(private profesorService: ProfesorService) {}

  ngOnInit() {
    this.reloadData();
  }

  reloadData() {
    this.profesores = this.profesorService.getProfesorList();
  }

  deleteProfesor(dni: string) {
    this.profesorService.deleteProfesor(dni)
      .subscribe(
        data => {
          console.log(data);
          this.reloadData();
        },
        error => console.log(error));
  }
}
