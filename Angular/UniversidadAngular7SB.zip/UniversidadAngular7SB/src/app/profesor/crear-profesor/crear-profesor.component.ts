import { ProfesorService } from '../../profesor.service';
import { Profesor } from '../../profesor';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-crear-profesor',
  templateUrl: './crear-profesor.component.html',
  styleUrls: ['./crear-profesor.component.css']
})
export class CrearProfesorComponent implements OnInit {

  profesor: Profesor = new Profesor();
  submitted = false;

  constructor(private profesorService: ProfesorService) { }

  ngOnInit() {
  }

  newProfesor(): void {
    this.submitted = false;
    this.profesor = new Profesor();
  }

  save() {
    this.profesorService.createProfesor(this.profesor)
      .subscribe(data => console.log(data), error => console.log(error));
    this.profesor = new Profesor();
  }

  onSubmit() {
    this.submitted = true;
    this.save();
  }
}