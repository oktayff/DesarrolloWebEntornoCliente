import { Profesor } from '../../profesor';
import { Component, OnInit, Input } from '@angular/core';
import { ProfesorService } from '../../profesor.service';
import { ProfesorListaComponent } from '../profesor-lista/profesor-lista.component';

@Component({
  selector: 'app-profesor-detalles',
  templateUrl: './profesor-detalles.component.html',
  styleUrls: ['./profesor-detalles.component.css']
})
export class ProfesorDetallesComponent implements OnInit {

  @Input() profesor: Profesor;

  constructor(private profesorService: ProfesorService, private listComponent: ProfesorListaComponent) { }

  ngOnInit() {
  }
}
