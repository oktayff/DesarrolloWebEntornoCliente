import { Observable } from "rxjs";
import { PersonaService } from "../../persona.service";
import { Persona } from "../../persona";
import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-persona-lista",
  templateUrl: "./persona-lista.component.html",
  styleUrls: ["./persona-lista.component.css"]
})
export class PersonaListaComponent implements OnInit {
  personas: Observable<Persona[]>;

  constructor(private personaService: PersonaService) {}

  ngOnInit() {
    this.reloadData();
  }

  reloadData() {
    this.personas = this.personaService.getPersonaList();
  }

  deletePersona(dni: string) {
    this.personaService.deletePersona(dni)
      .subscribe(
        data => {
          console.log(data);
          this.reloadData();
        },
        error => console.log(error));
  }
}
