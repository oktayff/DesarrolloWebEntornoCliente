import { Persona } from '../../persona';
import { Component, OnInit, Input } from '@angular/core';
import { PersonaService } from '../../persona.service';
import { PersonaListaComponent } from '../persona-lista/persona-lista.component';

@Component({
  selector: 'app-persona-detalles',
  templateUrl: './persona-detalles.component.html',
  styleUrls: ['./persona-detalles.component.css']
})
export class PersonaDetallesComponent implements OnInit {

  @Input() persona: Persona;

  constructor(private personaService: PersonaService, private listComponent: PersonaListaComponent) { }

  ngOnInit() {
  }
}