import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AlumnoService {

  private baseUrl = '/alumno';

  constructor(private http: HttpClient) { }

  getAlumno(dni: string): Observable<Object> {
    return this.http.get(`${this.baseUrl}/${dni}`);
  }

  createAlumno(alumno: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}`, alumno);
  }

  updateAlumno(dni: string, value: any): Observable<Object> {
    return this.http.put(`${this.baseUrl}/${dni}`, value);
  }

  deleteAlumno(dni: string): Observable<any> {
    return this.http.delete(`${this.baseUrl}/${dni}`, { responseType: 'text' });
  }

  getAlumnoList(): Observable<any> {
    return this.http.get(`${this.baseUrl}`);
  }
}