import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

//Titulacion
import { CrearTitulacionComponent } from './titulacion/crear-titulacion/crear-titulacion.component';
import { TitulacionDetallesComponent } from './titulacion/titulacion-detalles/titulacion-detalles.component';
import { TitulacionListaComponent } from './titulacion/titulacion-lista/titulacion-lista.component';
import { HttpClientModule } from '@angular/common/http';

//Persona
import { CrearPersonaComponent } from './persona/crear-persona/crear-persona.component';
import { PersonaDetallesComponent } from './persona/persona-detalles/persona-detalles.component';
import { PersonaListaComponent } from './persona/persona-lista/persona-lista.component';

//Alumno
import { CrearAlumnoComponent } from './alumno/crear-alumno/crear-alumno.component';
import { AlumnoDetallesComponent } from './alumno/alumno-detalles/alumno-detalles.component';
import { AlumnoListaComponent } from './alumno/alumno-lista/alumno-lista.component';

//Profesor
import { CrearProfesorComponent } from './profesor/crear-profesor/crear-profesor.component';
import { ProfesorDetallesComponent } from './profesor/profesor-detalles/profesor-detalles.component';
import { ProfesorListaComponent } from './profesor/profesor-lista/profesor-lista.component';

//Asignatura
import { CrearAsignaturaComponent } from './asignatura/crear-asignatura/crear-asignatura.component';
import { AsignaturaDetallesComponent } from './asignatura/asignatura-detalles/asignatura-detalles.component';
import { AsignaturaListaComponent } from './asignatura/asignatura-lista/asignatura-lista.component';

@NgModule({
  declarations: [
    AppComponent,

    //Titulacion
    CrearTitulacionComponent,
    TitulacionDetallesComponent,
    TitulacionListaComponent,

    //Persona
    CrearPersonaComponent,
    PersonaDetallesComponent,
    PersonaListaComponent,

    //Alumno
    CrearAlumnoComponent,
    AlumnoDetallesComponent,
    AlumnoListaComponent,

    //Profesor
    CrearProfesorComponent,
    ProfesorDetallesComponent,
    ProfesorListaComponent,

    //Asignatura
    CrearAsignaturaComponent,
    AsignaturaDetallesComponent,
    AsignaturaListaComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }