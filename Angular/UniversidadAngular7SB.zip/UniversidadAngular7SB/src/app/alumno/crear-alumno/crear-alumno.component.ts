import { AlumnoService } from '../../alumno.service';
import { Alumno } from '../../alumno';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-crear-alumno',
  templateUrl: './crear-alumno.component.html',
  styleUrls: ['./crear-alumno.component.css']
})
export class CrearAlumnoComponent implements OnInit {

  alumno: Alumno = new Alumno();
  submitted = false;

  constructor(private alumnoService: AlumnoService) { }

  ngOnInit() {
  }

  newAlumno(): void {
    this.submitted = false;
    this.alumno = new Alumno();
  }

  save() {
    this.alumnoService.createAlumno(this.alumno)
      .subscribe(data => console.log(data), error => console.log(error));
    this.alumno = new Alumno();
  }

  onSubmit() {
    this.submitted = true;
    this.save();
  }
}
