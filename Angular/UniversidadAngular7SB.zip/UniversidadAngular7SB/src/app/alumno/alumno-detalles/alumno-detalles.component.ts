import { Alumno } from '../../alumno';
import { Component, OnInit, Input } from '@angular/core';
import { AlumnoService } from '../../alumno.service';
import { AlumnoListaComponent } from '../alumno-lista/alumno-lista.component';

@Component({
  selector: 'app-alumno-detalles',
  templateUrl: './alumno-detalles.component.html',
  styleUrls: ['./alumno-detalles.component.css']
})
export class AlumnoDetallesComponent implements OnInit {

  @Input() alumno: Alumno;

  constructor(private alumnoService: AlumnoService, private listComponent: AlumnoListaComponent) { }

  ngOnInit() {
  }
}
