import { Observable } from "rxjs";
import { AlumnoService } from "../../alumno.service";
import { Alumno } from "../../alumno";
import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-alumno-lista",
  templateUrl: "./alumno-lista.component.html",
  styleUrls: ["./alumno-lista.component.css"]
})
export class AlumnoListaComponent implements OnInit {
  alumnos: Observable<Alumno[]>;

  constructor(private alumnoService: AlumnoService) {}

  ngOnInit() {
    this.reloadData();
  }

  reloadData() {
    this.alumnos = this.alumnoService.getAlumnoList();
  }

  deletePersona(dni: string) {
    this.alumnoService.deleteAlumno(dni)
      .subscribe(
        data => {
          console.log(data);
          this.reloadData();
        },
        error => console.log(error));
  }
}
