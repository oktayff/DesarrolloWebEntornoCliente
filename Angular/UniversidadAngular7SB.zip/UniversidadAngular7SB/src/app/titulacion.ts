export class Titulacion {
    idtitulacion: number;
    nombre: string;
    
}