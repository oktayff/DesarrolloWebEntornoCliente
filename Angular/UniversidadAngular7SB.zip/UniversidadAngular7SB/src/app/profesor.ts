export class Profesor {
    idprofesor: string;
    dni: string;
}