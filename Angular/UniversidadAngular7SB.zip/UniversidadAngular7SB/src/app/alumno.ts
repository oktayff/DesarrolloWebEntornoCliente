export class Alumno {
    idalumno: string;
    dni: string;
}