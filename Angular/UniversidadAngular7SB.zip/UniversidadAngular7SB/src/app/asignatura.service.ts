import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AsignaturaService {

  private baseUrl = '/asignatura';

  constructor(private http: HttpClient) { }

  getAsignatura(idasignatura: string): Observable<Object> {
    return this.http.get(`${this.baseUrl}/${idasignatura}`);
  }

  createAsignatura(asignatura: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}`, asignatura);
  }

  updateAsignatura(idasignatura: string, value: any): Observable<Object> {
    return this.http.put(`${this.baseUrl}/${idasignatura}`, value);
  }

  deleteAsignatura(idasignatura: string): Observable<any> {
    return this.http.delete(`${this.baseUrl}/${idasignatura}`, { responseType: 'text' });
  }

  getAsignaturaList(): Observable<any> {
    return this.http.get(`${this.baseUrl}`);
  }
}