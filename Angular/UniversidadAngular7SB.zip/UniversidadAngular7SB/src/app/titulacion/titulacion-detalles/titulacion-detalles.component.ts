import { Titulacion } from '../../titulacion';
import { Component, OnInit, Input } from '@angular/core';
import { TitulacionService } from '../../titulacion.service';
import { TitulacionListaComponent } from '../titulacion-lista/titulacion-lista.component';

@Component({
  selector: 'app-titulacion-detalles',
  templateUrl: './titulacion-detalles.component.html',
  styleUrls: ['./titulacion-detalles.component.css']
})
export class TitulacionDetallesComponent implements OnInit {

  @Input() titulacion: Titulacion;

  constructor(private titulacionService: TitulacionService, private listComponent: TitulacionListaComponent) { }

  ngOnInit() {
  }
}
