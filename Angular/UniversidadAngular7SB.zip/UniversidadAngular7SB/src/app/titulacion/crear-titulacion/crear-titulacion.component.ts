import { TitulacionService } from '../../titulacion.service';
import { Titulacion } from '../../titulacion';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-crear-titulacion',
  templateUrl: './crear-titulacion.component.html',
  styleUrls: ['./crear-titulacion.component.css']
})
export class CrearTitulacionComponent implements OnInit {

  titulacion: Titulacion = new Titulacion();
  submitted = false;

  constructor(private titulacionService: TitulacionService) { }

  ngOnInit() {
  }

  newTitulacion(): void {
    this.submitted = false;
    this.titulacion = new Titulacion();
  }

  save() {
    this.titulacionService.createTitulacion(this.titulacion)
      .subscribe(data => console.log(data), error => console.log(error));
    this.titulacion = new Titulacion();
  }

  onSubmit() {
    this.submitted = true;
    this.save();
  }
}