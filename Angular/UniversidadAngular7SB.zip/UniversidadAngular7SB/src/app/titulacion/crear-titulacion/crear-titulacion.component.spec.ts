import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CrearTitulacionComponent } from './crear-titulacion.component';

describe('CrearTitulacionComponent', () => {
  let component: CrearTitulacionComponent;
  let fixture: ComponentFixture<CrearTitulacionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CrearTitulacionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CrearTitulacionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
