import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TitulacionListaComponent } from './titulacion-lista.component';

describe('TitulacionListaComponent', () => {
  let component: TitulacionListaComponent;
  let fixture: ComponentFixture<TitulacionListaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TitulacionListaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TitulacionListaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
