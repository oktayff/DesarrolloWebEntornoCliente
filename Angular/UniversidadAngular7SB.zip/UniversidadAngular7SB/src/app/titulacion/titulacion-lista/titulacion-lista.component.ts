import { Observable } from "rxjs";
import { TitulacionService } from "../../titulacion.service";
import { Titulacion } from "../../titulacion";
import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-titulacion-lista",
  templateUrl: "./titulacion-lista.component.html",
  styleUrls: ["./titulacion-lista.component.css"]
})
export class TitulacionListaComponent implements OnInit {
  titulaciones: Observable<Titulacion[]>;

  constructor(private titulacionService: TitulacionService) {}

  ngOnInit() {
    this.reloadData();
  }

  reloadData() {
    this.titulaciones = this.titulacionService.getTitulacionList();
  }

  deleteTitulacion(idtitulacion: number) {
    this.titulacionService.deleteTitulacion(idtitulacion)
      .subscribe(
        data => {
          console.log(data);
          this.reloadData();
        },
        error => console.log(error));
  }
}
