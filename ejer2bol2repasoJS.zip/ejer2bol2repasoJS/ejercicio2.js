function insertar() {

	let tabla = document.getElementById("miTabla");
	let fila = tabla.insertRow();
	let col1 = fila.insertCell(0);
	let col2 = fila.insertCell(1);
	let col3 = fila.insertCell(2);
	let col4 = fila.insertCell(3);

	let num = prompt("Introduzca el numero de empleado");
	let dni = prompt("Introduzca el DNI del empleado");
	let nombre = prompt("Introduzca el nombre del empleado");
	let apellidos = prompt("Introduzca los apellidos del empleado");

	let dnis = [];

	let dniRecuperado = document.getElementById("dniemp").textContent;

	for(i=0; i<dnis.size(); i++){
		dnis.push(dniRecuperado);
	}

	console.log(dnis);

}

function borrar() {

	let tabla = document.getElementById("miTabla");

}

function modificar() {


}